-- MariaDB dump 10.19  Distrib 10.4.27-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: bndh
-- ------------------------------------------------------
-- Server version	10.4.27-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `abonos`
--

DROP TABLE IF EXISTS `abonos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abonos` (
  `IDAbonos` int(11) NOT NULL AUTO_INCREMENT,
  `IDPrestamos` int(11) NOT NULL,
  `CantidadAbonar` decimal(20,2) NOT NULL,
  `Fecha` date NOT NULL,
  `Hora` time NOT NULL,
  `IDSucursal` int(11) NOT NULL,
  `IDEmpleado` int(11) NOT NULL,
  `nombre_persona` varchar(50) NOT NULL,
  PRIMARY KEY (`IDAbonos`),
  KEY `IDPrestamos` (`IDPrestamos`),
  KEY `IDSucursal` (`IDSucursal`),
  KEY `IDEmpleado` (`IDEmpleado`),
  CONSTRAINT `FK_abonos_empleados` FOREIGN KEY (`IDEmpleado`) REFERENCES `empleados` (`IDEmpleado`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_abonos_prestamos` FOREIGN KEY (`IDPrestamos`) REFERENCES `prestamos` (`IDPrestamo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_abonos_sucursales` FOREIGN KEY (`IDSucursal`) REFERENCES `sucursales` (`IDSucursal`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abonos`
--

LOCK TABLES `abonos` WRITE;
/*!40000 ALTER TABLE `abonos` DISABLE KEYS */;
/*!40000 ALTER TABLE `abonos` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `abono` BEFORE INSERT ON `abonos` FOR EACH ROW BEGIN
	UPDATE prestamos set CantidadRestante=CantidadRestante-new.CantidadAbonar where IDPrestamo=1;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `cajeros`
--

DROP TABLE IF EXISTS `cajeros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cajeros` (
  `IDCajeros` int(11) NOT NULL AUTO_INCREMENT,
  `id_estado` int(11) NOT NULL,
  `ciudad` varchar(50) NOT NULL,
  `colonia` varchar(50) NOT NULL,
  `codigo_postal` varchar(5) NOT NULL,
  `municipio` varchar(50) NOT NULL,
  `calle` varchar(50) NOT NULL,
  PRIMARY KEY (`IDCajeros`),
  KEY `id_estado` (`id_estado`),
  CONSTRAINT `FK_cajeros_estados` FOREIGN KEY (`id_estado`) REFERENCES `estados` (`IDEstado`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cajeros`
--

LOCK TABLES `cajeros` WRITE;
/*!40000 ALTER TABLE `cajeros` DISABLE KEYS */;
/*!40000 ALTER TABLE `cajeros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente` (
  `IDCliente` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) NOT NULL,
  `Apellido` varchar(50) NOT NULL,
  `IdentificacionOF` text NOT NULL,
  `Id_estado` int(11) NOT NULL,
  `Colonia` varchar(50) NOT NULL,
  `Ciudad` varchar(50) NOT NULL,
  `Municipio` varchar(50) NOT NULL,
  `Calle` varchar(50) NOT NULL,
  `NumExterior` varchar(5) NOT NULL,
  `NumInterior` varchar(5) DEFAULT NULL,
  `CodigoPostal` varchar(5) NOT NULL,
  `FechaDeApertura` datetime NOT NULL,
  `TelefonoMovil` varchar(15) NOT NULL,
  `TelefonoLocal` varchar(15) NOT NULL,
  PRIMARY KEY (`IDCliente`),
  UNIQUE KEY `TelefonoMovil` (`TelefonoMovil`),
  KEY `Id_estado` (`Id_estado`),
  CONSTRAINT `FK_cliente_estados` FOREIGN KEY (`Id_estado`) REFERENCES `estados` (`IDEstado`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,'ESTEBAN','MARTINEZ MARTINEZ','61426253884',1,'CENTRO','HUAZALINGO','HUAZALINGO','FRENTE A LA IGLESIA','4',NULL,'43070','2023-01-29 17:21:25','7725243252','7896253525'),(2,'JUAN','HERNANDEZ HERNANDEZ','12512445653',1,'CENTRO','PACHUCA','PACHUCA DE SOTO','LIBERTAD','323','1','42000','2023-01-12 19:00:58','7712361527','7897667576'),(3,'SARA','FRANCO CASTAÑO','72636328362',1,'CENTRO','HUEJUTLA','HUEJUTLA DE REYES','REVOLUCIÓN','12',NULL,'43000','2023-01-12 11:00:00','7716216878','7897676755'),(6,'ANGEL','ISLAS HERNANDEZ','83897289687',1,'CENTRO','TULA','TULA DE ALLENDE','FRATERNIDAD','SN',NULL,'42787','2023-01-29 17:30:49','7712675788','7897843635'),(7,'PEDRO','ISRAEL TORRES','46723467653',1,'CENTRO','TLAHUELILPAN','TLAHUELILPAN','PARQUESITO','121','1','42328','2023-01-29 17:33:19','5598678688','7896152451'),(8,'JULIAN','TOLENTINO CRISTIANO','73872687786',1,'CENTRO','ATLAPEXCO','ATLAPEXCO','FRESNILLO','12',NULL,'43018','2023-01-29 17:46:09','7868768689','7899875762'),(9,'ISSAC','CRUZ REYES','82186876827',1,'CENTRO','XOCHIATIPAN','XOCHIATIPAN','PRINCIPAL','323',NULL,'43287','2023-01-29 17:53:34','7716467587','7716567268'),(10,'VICTORIA','BAUTISTA CRUZ','71262618649',1,'CENTRO','YAHUALICA','YAHUALICA','LOS ROBLES','SN',NULL,'43081','2023-01-29 17:56:46','8179868775','7897875786'),(16,'EDUARDO','HERNANDEZ HERNANDEZ ','87687576548',1,'CENTRO','JALTOCAN','JALTOCAN','ESTE 1','1287','12423','43089','2023-01-01 23:23:13','8776878587','5681757641'),(17,'ANGEL YAHIR','HERNANDEZ CASTILLO','17769187521',1,'CENTRO','ACTOPAN','ACTOPAN','ORIENTE 1','SN',NULL,'42879','2023-01-29 18:00:45','7716661723','7717656182'),(19,'MONSSERRATH','ROJO BAUTISTA','77162592332',1,'CENTRO','PISAFLORES','PISAFLORES','PONIENTE 2','19',NULL,'43017','2023-01-12 12:23:21','7778152761','7765781821'),(20,'PETRA','BAUTISTA HERNANDEZ','98618726876',1,'CENTRO','TIANGUISTENGO','TIANGUISTENGO','NORTE 4','12',NULL,'42009','2023-01-13 12:32:32','7715275712','7897817232'),(21,'INES','VALENTIN TRATADO','89621828991',1,'CENTRO','TLAHUILTEPA','TLAHUILTEPA','PRINCIPAL','1',NULL,'42877','2023-01-10 08:12:32','7715526277','7712567134'),(22,'NICOLAS','BARRAGAN SANTIAGO','71872576234',1,'CENTRO','CARDONAL','CARDONAL','20 DE ENERO','SN',NULL,'42901','2023-01-29 19:10:50','8189868762','8109798687'),(25,'GUILLERMO','HERNANDEZ TOLENTINO','98688192783',1,'CENTRO','CHAPANTONGO','CHAPANTONGO','24 DE DICIEMBRE','2','1','42091','2023-01-29 19:12:17','7767157629','7713275677');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cuenta_cliente`
--

DROP TABLE IF EXISTS `cuenta_cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cuenta_cliente` (
  `IDNumCuenta` int(11) NOT NULL AUTO_INCREMENT,
  `NumCuenta` int(16) NOT NULL,
  `IDTipoCuenta` int(11) NOT NULL,
  `Saldo` decimal(20,2) NOT NULL,
  `Sucursal` int(11) NOT NULL,
  `Fecha` datetime NOT NULL,
  `id_clientr` int(11) NOT NULL,
  PRIMARY KEY (`IDNumCuenta`),
  KEY `IDTipoCuenta` (`IDTipoCuenta`),
  KEY `Sucursal` (`Sucursal`),
  KEY `id_clientr` (`id_clientr`),
  CONSTRAINT `FK_cuenta_cliente_cliente` FOREIGN KEY (`id_clientr`) REFERENCES `cliente` (`IDCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_cuenta_cliente_sucursales` FOREIGN KEY (`Sucursal`) REFERENCES `sucursales` (`IDSucursal`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_cuenta_cliente_tipo_de_cuenta` FOREIGN KEY (`IDTipoCuenta`) REFERENCES `tipo_de_cuenta` (`IDTipocuenta`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuenta_cliente`
--

LOCK TABLES `cuenta_cliente` WRITE;
/*!40000 ALTER TABLE `cuenta_cliente` DISABLE KEYS */;
/*!40000 ALTER TABLE `cuenta_cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empleados`
--

DROP TABLE IF EXISTS `empleados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empleados` (
  `IDEmpleado` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) NOT NULL,
  `Apellido` varchar(50) NOT NULL,
  `Colonia` varchar(50) NOT NULL,
  `Municipio` varchar(50) NOT NULL,
  `Calle` varchar(50) NOT NULL,
  `codigo_postal` varchar(5) NOT NULL,
  `id_estado` int(11) NOT NULL,
  `num_exterior` int(11) NOT NULL,
  `IDPuesto` int(11) NOT NULL,
  `Telefono` varchar(15) NOT NULL,
  PRIMARY KEY (`IDEmpleado`),
  KEY `IDPuesto` (`IDPuesto`),
  KEY `id_estado` (`id_estado`),
  CONSTRAINT `FK_empleados_estados` FOREIGN KEY (`id_estado`) REFERENCES `estados` (`IDEstado`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_empleados_puesto` FOREIGN KEY (`IDPuesto`) REFERENCES `puesto` (`IDPuesto`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleados`
--

LOCK TABLES `empleados` WRITE;
/*!40000 ALTER TABLE `empleados` DISABLE KEYS */;
INSERT INTO `empleados` VALUES (1,'MAURICIO','PANFILO PEREZ','SANTA IRENE','HUEJUTLA DE REYES','SAN PEDRO','43000',1,42,1,'7716235252'),(4,'JUANA VICTORIA','CRUZ CRUZ','SANTA MONICA','HUEJUTLA DE REYES','3 ORIENTE','43000',1,1,2,'7715244362'),(5,'ANGEL YAHIR','HERNANDEZ ISLAS','CENTRO','HUEJUTLA DE REYES','AV 20 DE NOVIEMBRE','43000',1,12,2,'7762536726'),(6,'MARIA DEL ANGEL','BAUTISTA HERNANDEZ','DOMICILIO CONOCIDO','HUAZALINGO','FRENTE A LA PRESIDENCIA','43070',1,0,1,'7726345223'),(9,'ISSAC','TOLENTINO OCHOA','DOMICILIO CONOCIDO','HUAZALINGO','FRENTE A LA IGLESIA','43070',1,0,2,'5526365231');
/*!40000 ALTER TABLE `empleados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empresa`
--

DROP TABLE IF EXISTS `empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empresa` (
  `id_empresa` int(11) NOT NULL AUTO_INCREMENT,
  `nombreEmpresa` varchar(50) NOT NULL,
  PRIMARY KEY (`id_empresa`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresa`
--

LOCK TABLES `empresa` WRITE;
/*!40000 ALTER TABLE `empresa` DISABLE KEYS */;
INSERT INTO `empresa` VALUES (1,'Banco Nacional de Huejutla');
/*!40000 ALTER TABLE `empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estados`
--

DROP TABLE IF EXISTS `estados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estados` (
  `IDEstado` int(11) NOT NULL AUTO_INCREMENT,
  `Estado` varchar(50) NOT NULL,
  PRIMARY KEY (`IDEstado`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estados`
--

LOCK TABLES `estados` WRITE;
/*!40000 ALTER TABLE `estados` DISABLE KEYS */;
INSERT INTO `estados` VALUES (1,'Hidalgo'),(2,'Veracruz'),(3,'Tlaxcala'),(4,'Puebla'),(5,'Queretaro'),(6,'Ciudad de Mexico'),(7,'Aguascalientes'),(8,'Baja California'),(9,'Baja California Sur'),(10,'Campeche'),(11,'Chiapas'),(12,'Chihuahua'),(13,'Colima'),(14,'Durango'),(15,'Coahuila'),(16,'Estado de Mexico'),(17,'Guanajuato'),(18,'Guerrero'),(19,'Jalisco'),(20,'Michoacan'),(21,'Morelos'),(22,'Nayarit'),(23,'Nuevo Leon'),(24,'Oaxaca'),(25,'Quintana Roo'),(26,'San Luis Potosi'),(27,'Sinaloa'),(28,'Sonora'),(29,'Tabasco'),(30,'Tamaulipas'),(31,'Yucatan'),(32,'Zacatecas');
/*!40000 ALTER TABLE `estados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estados_targetas`
--

DROP TABLE IF EXISTS `estados_targetas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estados_targetas` (
  `id_estadoTargeta` int(11) NOT NULL AUTO_INCREMENT,
  `estado` varchar(50) NOT NULL,
  `descripcion` varchar(50) NOT NULL,
  PRIMARY KEY (`id_estadoTargeta`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estados_targetas`
--

LOCK TABLES `estados_targetas` WRITE;
/*!40000 ALTER TABLE `estados_targetas` DISABLE KEYS */;
INSERT INTO `estados_targetas` VALUES (1,'encendido','La tarjeta es utilizable'),(2,'apagado',' Los cargos no proceden'),(3,'desactivado','El número de tarjeta está desactivado porque ya ex'),(4,'bloqueado','Fue robado o extraviado y no se puede hacer nada m');
/*!40000 ALTER TABLE `estados_targetas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movimientos_cajeros`
--

DROP TABLE IF EXISTS `movimientos_cajeros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movimientos_cajeros` (
  `id_movimiento` int(11) NOT NULL AUTO_INCREMENT,
  `IDCliente` int(11) NOT NULL,
  `IDTipoMov` int(11) NOT NULL,
  `Fecha` date NOT NULL,
  `Hora` time NOT NULL,
  `IDCajero` int(11) NOT NULL,
  `Cantidad` decimal(20,2) NOT NULL,
  PRIMARY KEY (`id_movimiento`),
  KEY `IDCliente` (`IDCliente`),
  KEY `IDTipoMov` (`IDTipoMov`),
  KEY `IDCajero` (`IDCajero`),
  CONSTRAINT `FK_movimientoscajeros_cajeros` FOREIGN KEY (`IDCajero`) REFERENCES `cajeros` (`IDCajeros`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_movimientoscajeros_cliente` FOREIGN KEY (`IDCliente`) REFERENCES `cliente` (`IDCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_movimientoscajeros_tiposdemovimientos` FOREIGN KEY (`IDTipoMov`) REFERENCES `tipos_movimientos` (`IDTipoMov`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movimientos_cajeros`
--

LOCK TABLES `movimientos_cajeros` WRITE;
/*!40000 ALTER TABLE `movimientos_cajeros` DISABLE KEYS */;
/*!40000 ALTER TABLE `movimientos_cajeros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movimientos_ventanilla`
--

DROP TABLE IF EXISTS `movimientos_ventanilla`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movimientos_ventanilla` (
  `id_movimiento` int(11) NOT NULL AUTO_INCREMENT,
  `IDNumCuenta` int(11) NOT NULL,
  `IDEmpleado` int(11) NOT NULL,
  `IDTipoMov` int(11) NOT NULL,
  `Cantidad` decimal(20,2) NOT NULL,
  `Fecha` date NOT NULL,
  `Hora` time NOT NULL,
  PRIMARY KEY (`id_movimiento`),
  KEY `IDNumCuenta` (`IDNumCuenta`),
  KEY `IDEmpleado` (`IDEmpleado`),
  KEY `IDTipoMov` (`IDTipoMov`),
  CONSTRAINT `FK_movimientosventanilla_cuenta_cliente` FOREIGN KEY (`IDNumCuenta`) REFERENCES `cuenta_cliente` (`IDNumCuenta`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_movimientosventanilla_empleados` FOREIGN KEY (`IDEmpleado`) REFERENCES `empleados` (`IDEmpleado`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_movimientosventanilla_tiposdemovimientos` FOREIGN KEY (`IDTipoMov`) REFERENCES `tipos_movimientos` (`IDTipoMov`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movimientos_ventanilla`
--

LOCK TABLES `movimientos_ventanilla` WRITE;
/*!40000 ALTER TABLE `movimientos_ventanilla` DISABLE KEYS */;
/*!40000 ALTER TABLE `movimientos_ventanilla` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movitrans`
--

DROP TABLE IF EXISTS `movitrans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movitrans` (
  `id_moviTrans` int(11) NOT NULL AUTO_INCREMENT,
  `IDCajeros` int(11) NOT NULL,
  `TotalMovi` int(11) NOT NULL,
  PRIMARY KEY (`id_moviTrans`),
  KEY `IDCajeros` (`IDCajeros`),
  CONSTRAINT `FK_movitrans_cajeros` FOREIGN KEY (`IDCajeros`) REFERENCES `cajeros` (`IDCajeros`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movitrans`
--

LOCK TABLES `movitrans` WRITE;
/*!40000 ALTER TABLE `movitrans` DISABLE KEYS */;
/*!40000 ALTER TABLE `movitrans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `periodos_creditos`
--

DROP TABLE IF EXISTS `periodos_creditos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `periodos_creditos` (
  `IDPeriodoCredito` int(11) NOT NULL AUTO_INCREMENT,
  `Periodos` varchar(50) NOT NULL,
  `PorcetanjeDeInteres` int(11) NOT NULL,
  PRIMARY KEY (`IDPeriodoCredito`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `periodos_creditos`
--

LOCK TABLES `periodos_creditos` WRITE;
/*!40000 ALTER TABLE `periodos_creditos` DISABLE KEYS */;
INSERT INTO `periodos_creditos` VALUES (1,'cortoPlazo',30),(2,'medianoPlazo',50),(3,'largoPlazo',80);
/*!40000 ALTER TABLE `periodos_creditos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prestamos`
--

DROP TABLE IF EXISTS `prestamos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prestamos` (
  `IDPrestamo` int(11) NOT NULL AUTO_INCREMENT,
  `IDCliente` int(11) NOT NULL,
  `CantidadPrestada` decimal(20,2) NOT NULL,
  `Intereses` decimal(20,2) NOT NULL,
  `IDPeriodoCredito` int(11) NOT NULL,
  `CantidadTotal` decimal(20,2) NOT NULL,
  `CantidadRestante` decimal(20,2) NOT NULL,
  PRIMARY KEY (`IDPrestamo`),
  KEY `IDCliente` (`IDCliente`),
  KEY `IDPeriodoCredito` (`IDPeriodoCredito`),
  CONSTRAINT `FK_prestamos_cliente` FOREIGN KEY (`IDCliente`) REFERENCES `cliente` (`IDCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_prestamos_periodosdecreditos` FOREIGN KEY (`IDPeriodoCredito`) REFERENCES `periodos_creditos` (`IDPeriodoCredito`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prestamos`
--

LOCK TABLES `prestamos` WRITE;
/*!40000 ALTER TABLE `prestamos` DISABLE KEYS */;
INSERT INTO `prestamos` VALUES (1,6,4000.00,30.00,1,5200.00,4000.00);
/*!40000 ALTER TABLE `prestamos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `puesto`
--

DROP TABLE IF EXISTS `puesto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `puesto` (
  `IDPuesto` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) NOT NULL,
  `Descripcion` varchar(150) NOT NULL,
  PRIMARY KEY (`IDPuesto`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `puesto`
--

LOCK TABLES `puesto` WRITE;
/*!40000 ALTER TABLE `puesto` DISABLE KEYS */;
INSERT INTO `puesto` VALUES (1,'Empleado de ventanilla','Encargado de los movimientos'),(2,'Autorizador de créditos','Encargado de autorizar los creditos ');
/*!40000 ALTER TABLE `puesto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sucursales`
--

DROP TABLE IF EXISTS `sucursales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sucursales` (
  `IDSucursal` int(11) NOT NULL AUTO_INCREMENT,
  `Ciudad` varchar(50) NOT NULL,
  `NumSucursal` int(10) NOT NULL,
  `IDEstado` int(10) NOT NULL,
  `NombreSucursal` varchar(50) NOT NULL,
  `IDEmpresa` int(11) NOT NULL,
  PRIMARY KEY (`IDSucursal`),
  KEY `IDEstado` (`IDEstado`),
  KEY `IDEmpresa` (`IDEmpresa`),
  CONSTRAINT `FK_sucursales_empresa` FOREIGN KEY (`IDEmpresa`) REFERENCES `empresa` (`id_empresa`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_sucursales_estados` FOREIGN KEY (`IDEstado`) REFERENCES `estados` (`IDEstado`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sucursales`
--

LOCK TABLES `sucursales` WRITE;
/*!40000 ALTER TABLE `sucursales` DISABLE KEYS */;
INSERT INTO `sucursales` VALUES (1,'Huejutla de reyes',1,1,'Las lomas',1);
/*!40000 ALTER TABLE `sucursales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `targetas`
--

DROP TABLE IF EXISTS `targetas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `targetas` (
  `id_targeta` int(11) NOT NULL AUTO_INCREMENT,
  `num_targeta` int(16) NOT NULL,
  `ccv` int(3) NOT NULL,
  `fecha_expiracion` date NOT NULL,
  `fecha_activacion` date NOT NULL,
  `nip` int(4) NOT NULL,
  `id_num_cuenta` int(16) NOT NULL,
  `id_tipoTargeta` int(16) NOT NULL,
  `id_estadoTargeta` int(16) NOT NULL,
  PRIMARY KEY (`id_targeta`),
  UNIQUE KEY `num_targeta` (`num_targeta`),
  KEY `id_num_cuenta` (`id_num_cuenta`),
  KEY `id_tipoTargeta` (`id_tipoTargeta`),
  KEY `id_estadoTargeta` (`id_estadoTargeta`),
  CONSTRAINT `FK_targetas_cuenta_cliente` FOREIGN KEY (`id_num_cuenta`) REFERENCES `cuenta_cliente` (`IDNumCuenta`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_targetas_estados_targetas` FOREIGN KEY (`id_estadoTargeta`) REFERENCES `estados_targetas` (`id_estadoTargeta`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_targetas_tipos_targetas` FOREIGN KEY (`id_tipoTargeta`) REFERENCES `tipos_targetas` (`id_tipoTargeta`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `targetas`
--

LOCK TABLES `targetas` WRITE;
/*!40000 ALTER TABLE `targetas` DISABLE KEYS */;
/*!40000 ALTER TABLE `targetas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_de_cuenta`
--

DROP TABLE IF EXISTS `tipo_de_cuenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_de_cuenta` (
  `IDTipocuenta` int(11) NOT NULL AUTO_INCREMENT,
  `ConceptoCuenta` varchar(50) NOT NULL,
  PRIMARY KEY (`IDTipocuenta`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_de_cuenta`
--

LOCK TABLES `tipo_de_cuenta` WRITE;
/*!40000 ALTER TABLE `tipo_de_cuenta` DISABLE KEYS */;
INSERT INTO `tipo_de_cuenta` VALUES (1,'Ahorro'),(2,'Cheques'),(3,'Inversiones'),(4,'Nomina');
/*!40000 ALTER TABLE `tipo_de_cuenta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipos_movimientos`
--

DROP TABLE IF EXISTS `tipos_movimientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipos_movimientos` (
  `IDTipoMov` int(11) NOT NULL AUTO_INCREMENT,
  `Movimiento` varchar(50) NOT NULL,
  PRIMARY KEY (`IDTipoMov`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipos_movimientos`
--

LOCK TABLES `tipos_movimientos` WRITE;
/*!40000 ALTER TABLE `tipos_movimientos` DISABLE KEYS */;
INSERT INTO `tipos_movimientos` VALUES (1,'deposito'),(2,'retiro');
/*!40000 ALTER TABLE `tipos_movimientos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipos_targetas`
--

DROP TABLE IF EXISTS `tipos_targetas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipos_targetas` (
  `id_tipoTargeta` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(150) NOT NULL,
  PRIMARY KEY (`id_tipoTargeta`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipos_targetas`
--

LOCK TABLES `tipos_targetas` WRITE;
/*!40000 ALTER TABLE `tipos_targetas` DISABLE KEYS */;
INSERT INTO `tipos_targetas` VALUES (1,'Visa','Ofrece un servicio eficiente y seguro a los clientes'),(2,'MasterCard ',' Su principal ventaja es que con ella se obtienen diferentes descuentos en espectáculos, eventos, museos etc.'),(3,'American Express','Gran eficiencia que tienen en todos su trámites y por su programa de puntos para clientes.');
/*!40000 ALTER TABLE `tipos_targetas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-29 23:36:00
